# Vite & React 
Commands:
To install the required packages:
npm i
To run the dev server:
npm run dev
