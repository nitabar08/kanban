import React, {useEffect, useState, useCallback} from 'react';
import axios from 'axios';

import './App.css';

import List from './Components/List/List';
import Navbar from './Components/Navbar/Navbar';

function App() {
  const statusList = ['Backlog', 'Todo', 'In progress', 'Done', 'Cancelled']
  const userList = ['Anoop sharma', 'Yogesh', 'Shankar Kumar', 'Ramesh', 'Suresh']
  const priorityList = [{name:'No priority', priority: 0}, {name:'Urgent', priority: 4}, {name:'High', priority: 3}, {name:'Medium', priority: 2}, {name:'Low', priority: 1}]

  const [grpVal, setgrpVal] = useState(getState() || 'status')
  const [ordVal, setordVal] = useState('title')
  const [ticket, setticket] = useState([]);


  const orderByVal = useCallback(async (cardsArr) => {
    if (ordVal === 'priority') {
      cardsArr.sort((a, b) => b.priority - a.priority);
    } else if (ordVal === 'title') {
      cardsArr.sort((a, b) => {
        const t1 = a.title.toLowerCase();
        const t2 = b.title.toLowerCase();

        if (t1 < t2) {
          return -1;
        } else if (t1 > t2) {
          return 1;
        } else {
          return 0;
        }
      });
    }
    await setticket(cardsArr);
  }, [ordVal, setticket]);

  function saveState(state) {
    localStorage.setItem('groupValue', JSON.stringify(state));
  }

  function getState() {
    const storedState = localStorage.getItem('groupValue');
    if (storedState) {
      return JSON.parse(storedState);
    }
    return null; 
  }

  useEffect(() => {
    saveState(grpVal);
    async function fetchData() {
      const response = await axios.get('https://api.quicksell.co/v1/internal/frontend-assignment');
      await refactorData(response);
  
    }
    fetchData();
    async function refactorData(response){
      let Arrayticket = []
        if(response.status  === 200){
          for(let i=0; i<response?.data?.tickets?.length; i++){
            for(let j=0; j<response.data.users.length; j++){
              if(response.data.tickets[i].userId === response.data.users[j].id){
                let ticketJson = {...response.data.tickets[i], userObj: response.data.users[j]}
                Arrayticket.push(ticketJson)
              }
            }
          }
        }
      await setticket(Arrayticket)
      orderByVal(Arrayticket)
    }
    
  }, [orderByVal, grpVal])

  function handleGrpVal(value){
    setgrpVal(value);
    console.log(value);
  }

  function handleordVal(value){
    setordVal(value);
    console.log(value);
  }
  
  return (
    <>
      <Navbar
        groupValue={grpVal}
        orderValue={ordVal}
        handleGroupValue={handleGrpVal}
        handleOrderValue={handleordVal}
      />
      <section className="board-det">
        <div className="board-list">
          {
            {
              'status' : <>
                {
                  statusList.map((listItem) => {
                    return(<List
                      groupValue='status'
                      orderValue={ordVal}
                      listTitle={listItem}
                      listIcon=''
                      statusList={statusList}
                      ticketDetails={ticket}
                    />)
                  })
                }
              </>,
              'user' : <>
              {
                userList.map((listItem) => {
                  return(<List
                    groupValue='user'
                    orderValue={ordVal}
                    listTitle={listItem}
                    listIcon=''
                    userList={userList}
                    ticketDetails={ticket}
                  />)
                })
              }
              </>,
              'priority' : <>
              {
                priorityList.map((listItem) => {
                  return(<List
                    groupValue='priority'
                    orderValue={ordVal}
                    listTitle={listItem.priority}
                    listIcon=''
                    priorityList={priorityList}
                    ticketDetails={ticket}
                  />)
                })
              }
            </>
            }[grpVal]
          }
        </div>
      </section>
    </>
  );
}

export default App;
